#include <SDL.h>
#include <stdio.h>

SDL_Renderer *renderer;
SDL_Surface *brick;
SDL_Surface *ball;
SDL_Surface *win;
void destroy();
SDL_Surface *bat;
SDL_Surface *bk;
void gameover();

SDL_Texture *wintexture;
SDL_Texture *bricktexture;
SDL_Texture *balltexture;
SDL_Texture *bktexture;
SDL_Texture *battexture;
bool quit = false;
SDL_Event event;
int ballx = 10;
int bally = 10;
int ballvelx = 1;
int ballvely = 1;
int delete_brick_count = 0;
int no_of_bricks = 21;
int bricw = 80;
int brickh = 35;
int bkw = 800;
int bkh = 600;
int bkwmin = 0;
int bkhmin = 0;
int batx = bkw / 2;
int baty = bkh - 30;

SDL_Rect brickrect[3][7];
SDL_Rect ballrect;

enum GameState
{
    MENU,
    PLAYING,
    GAME_OVER,
    WIN
};

GameState gameState = MENU;

void initializebrick()
{
    // Your existing code for initializing bricks
    brickrect[0][0]={50,50,bricw,brickh};
	brickrect[0][1]={150,50,bricw,brickh};
	brickrect[0][2]={250,50,bricw,brickh};
	brickrect[0][3]={350,50,bricw,brickh};
	brickrect[0][4]={450,50,bricw,brickh};
	brickrect[0][5]={550,50,bricw,brickh};
	brickrect[0][6]={650,50,bricw,brickh};
	brickrect[1][0]={50,100,bricw,brickh};
	brickrect[1][1]={150,100,bricw,brickh};
	brickrect[1][2]={250,100,bricw,brickh};
	brickrect[1][3]={350,100,bricw,brickh};
	brickrect[1][4]={450,100,bricw,brickh};
	brickrect[1][5]={550,100,bricw,brickh};
	brickrect[1][6]={650,100,bricw,brickh};
	brickrect[2][0]={50,150,bricw,brickh};
	brickrect[2][1]={150,150,bricw,brickh};
	brickrect[2][2]={250,150,bricw,brickh};
	brickrect[2][3]={350,150,bricw,brickh};
	brickrect[2][4]={450,150,bricw,brickh};
	brickrect[2][5]={550,150,bricw,brickh};
	brickrect[2][6]={650,150,bricw,brickh};
    // ...
}

void eventhandler()
{
	 SDL_PollEvent(&event);
	 if(event.type==SDL_QUIT){
	 	quit=true;
	 }
	else if(event.type==SDL_KEYDOWN)
	{
		if(event.key.keysym.sym==SDLK_LEFT&&batx>0){
		 	batx=batx-1;
		}
		 if(event.key.keysym.sym==SDLK_RIGHT&&batx<bkw-80){
		 	batx=batx+1;
		}
	}
		 
}
void moveball()
{
	ballx= ballx + ballvelx;
	bally= bally + ballvely;
	if(bkh==ballx&&bkw==bally)
			{
				ballvelx=-ballvelx;
				ballvely=-ballvely;
			}
}
void ballcollision() // for ball collision 
{
	if(ballx<bkwmin||ballx>bkw-30)
			{
				ballvelx=-ballvelx;
			}
	if(bally<bkhmin)
			{
				ballvely=-ballvely;
			}
		if(bally>bkh+60){
			gameover();
		}
	int ballscaling = 20;
	if(bally+ballscaling>=baty&&bally+ballscaling<=baty+60 &&ballx+ballscaling>=batx &&ballx+ballscaling<=batx+30){
		ballvely=-ballvely;
	}
}
	
bool ball_brick_collision_detect(SDL_Rect rect1,SDL_Rect rect2){
	if(rect1.x>rect2.x+rect2.w){
		return false;
	}
	if( rect1.x+rect1.w< rect2.x){
		return false;
	}
	if(rect1.y>rect2.y+rect2.h){
		return false;
	}
	if(rect1.y+rect1.h<rect2.y){
		return false;
	}
	return true;
}
void ball_brick_collision(){
	bool a;
	for (int i=0;i<3;i++){
		for(int j=0;j<7;j++){
			a=ball_brick_collision_detect(brickrect[i][j],ballrect); // check the ball collision with brick
		if (a==true){
			brickrect[i][j].x=3000;
			ballvely = -ballvely;
			delete_brick_count++;
}
}
}
}
void destroy(){
	SDL_DestroyTexture(battexture);
	SDL_DestroyTexture(bricktexture);
	SDL_DestroyTexture(bktexture);
	SDL_DestroyTexture(balltexture);
	SDL_FreeSurface(bat);
	SDL_FreeSurface(ball);
	SDL_FreeSurface(bk);
	SDL_DestroyRenderer(renderer);
	//SDL_DestroyWin(win);
}
void winning(){
	win = SDL_LoadBMP("win.bmp");
	wintexture = SDL_CreateTextureFromSurface(renderer,win);
	SDL_Rect winrect ={0,0,bkw,bkh};
	SDL_RenderCopy(renderer,wintexture,NULL,&winrect);
	SDL_RenderPresent(renderer);
	SDL_Delay(10000);
	destroy();
	SDL_Quit();
}
void gameover(){
	SDL_Surface*go = SDL_LoadBMP("gameover.bmp");
	SDL_Texture *gotexture = SDL_CreateTextureFromSurface(renderer,go);
	SDL_Rect gorect ={0,0,bkw,bkh};
	SDL_RenderCopy(renderer,gotexture,NULL,&gorect);
	SDL_RenderPresent(renderer);
	SDL_Delay(10000);
	destroy();
	SDL_Quit();
}

int main(int argc, char **argv)
{
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window *window = SDL_CreateWindow("Brick breaker ", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, 0);
    renderer = SDL_CreateRenderer(window, -1, 0);

    initializebrick();

    while (!quit)
    {
        switch (gameState)
        {
        case MENU:
            // Your menu logic
            eventhandler(); // Handle events in the menu
            break;

        case PLAYING:
            // Your game logic
            eventhandler();      // Handle events during gameplay
            moveball();          // Move the ball
            ballcollision();     // Handle ball collisions
            ball_brick_collision(); // Handle ball-brick collisions
            // Check win/lose conditions and update gameState accordingly
            if (delete_brick_count == no_of_bricks)
            {
                gameState = WIN;
            }
            else if (bally>bkh+60)
            {
                gameState = GAME_OVER;
            }
            break;

        case GAME_OVER:
            // Your game over logic
            eventhandler(); // Handle events in the game over screen
            gameover();
            break;

        case WIN:
            eventhandler(); // Handle events in the win screen
            winning();
            break;
        }

        SDL_RenderPresent(renderer);
        SDL_RenderClear(renderer);
    }

    destroy();
    SDL_Quit();

    return 0;
}

